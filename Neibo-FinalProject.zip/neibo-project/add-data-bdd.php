<?php
$nom = filter_input(INPUT_POST,'nom'); 
$prenom = filter_input(INPUT_POST,'prenom');  
$email = filter_input(INPUT_POST,'email');  
$mdp = filter_input(INPUT_POST,'mdp'); 
$tel = filter_input(INPUT_POST,'tel'); 

$engine = "mysql";
$host = "localhost";
$port = 8889;  
$dbname = "neibo";
$username = "root";
$password = "root"; 

$pdo = new PDO("$engine:host=$host:$port;dbname=$dbname", $username, $password);

// Etape 1 : On prépare la requête
if($nom && $prenom && $email && $mdp && $tel) {
    $mdp = password_hash(filter_input(INPUT_POST, "mdp"),PASSWORD_DEFAULT); 
    $stmt = $pdo->prepare('INSERT INTO users (nom,prenom,email,mdp,tel) VALUES(:nom,:prenom,:email,:mdp,:tel)');
    // Etape 2 : On met les variables
    $stmt->execute([
        'nom' => $nom,
        'prenom' => $prenom,
        'email' => $email,
        'mdp' => $mdp,
        'tel' => $tel,
    ]); 

    $_SESSION["connecte"] = true;
}

