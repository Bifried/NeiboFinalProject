async function initMap() {

    // CHECK IF LOCATION IS OK 
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        
        // USER GEOCODE
        let usergeocode = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        }
       

        // GET USER LOCATION
        const  getUserAddress = async () => {
         
          let url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${usergeocode.latitude},${usergeocode.longitude}&key=AIzaSyCn07pIPdU6DgccvDqdoju8wiYmihIQC1w`
          let response = await fetch(url)
          let address = await response.json()
          
          // WRITE FORMATED ADDRESS
          const location_text = document.querySelector('.location-text')
          location_text.textContent = address.results[0].formatted_address
          
        }
       getUserAddress()

        // A GOOGLE MAP OBJECT
        let myLatLng = new google.maps.LatLng(usergeocode.latitude, usergeocode.longitude )
        
        // MAP OPTIONS
        let mapOptions = {
          mapId: '55ade2af0bd3af8e',
          zoom: 14,
          
          center: myLatLng,
          
          disableDefaultUI: true,
          mapTypeControlOptions: {
            streetViewControl: false,
            mapTypeIds: google.maps.MapTypeId.ROADMAP
          }
         

        }
       
      //  SETUP GOOGLE MAP API
        let map;

      //  TARGET MAP IN THE DOM (HTML)
        map =  new google.maps.Map(document.getElementById("map"),mapOptions);
        let myPosition = new google.maps.Marker({
          position: myLatLng
        })
        myPosition.setMap(map)  


        // GET COMMERCES DATA
        const getCommerces = async () => {

          // DATA FILE
          let url = 'js/commerces.json'
          let response = await fetch(url)
          let commerces = await response.json()
         

          // GET LONG LAT 

          for (let i = 0; i < commerces.length; i++) {
            const adresse = commerces[i].fields.adresse
            const nom = commerces[i].fields.nom_du_commerce
            const zipCode = commerces[i].fields.code_postal
            const description = commerces[i].fields.description
            const telephone = commerces[i].fields.telephone

            const geocode = {
              Lat : commerces[i].fields.geo_point_2d[0],
              Long :  commerces[i].fields.geo_point_2d[1]
            }
           
            let googleGeocode = new google.maps.LatLng(geocode.Lat, geocode.Long )


            const contentString = 

                '<div id="content">' +
                '<div id="siteNotice">' +
                "</div>" +
                `<h1 id="firstHeading" class="firstHeading">${nom}</h1>` +
                '<div id="bodyContent">' +
                `<h2 id="secondtHeading" class="secondHeading">${adresse}, ${zipCode} Paris </h2>` + 
                `<h3 id="thirdtHeading" class="thirdHeading">${telephone}</h3>`
                +
                `<p>${description}</p>` +
                "</div>" +
                "</div>";
                
            let commercesPosition = new google.maps.Marker({
              position: googleGeocode
            })


            const infowindow = new google.maps.InfoWindow({
              content : contentString,
            })
           
            // ADD MARKER TO MAP
            commercesPosition.addListener('click', () => {

              infowindow.open(map, commercesPosition )
              
            })
            commercesPosition.setMap(map)
            commercesPosition.setIcon('http://maps.google.com/mapfiles/ms/icons/purple-dot.png')
          }

         
        

          
        }
        getCommerces()
    });
        } else {
          alert('Map is not available.');
        }
  }
 
initMap()


// const displayMode = () => {
//     const mapBtn = document.querySelector('.map-mode')
//     const list = document.querySelector('.items-list')

//     const map = document.querySelector('#map')
//     const catalog = document.querySelector('#catalog')



    
//     mapBtn.addEventListener('click', ()=>{
//       catalog.style.visibility = 'hidden'
//       map.style.visibility = 'visible'
//       mapBtn.style.backgroundColor = '#5C18C9'
//       list.style.backgroundColor = 'transparent'

//     })
//     list.addEventListener('click', ()=>{
//       catalog.style.visibility = 'visible'
//       map.style.visibility = 'hidden'
//       list.style.backgroundColor = '#5C18C9'
//       mapBtn.style.backgroundColor = 'transparent'
//     })




// }
// displayMode()
