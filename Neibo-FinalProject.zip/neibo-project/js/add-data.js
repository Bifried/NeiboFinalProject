document.addEventListener('submit',() => {

    const dataValue = document.querySelector('#nom').value
    const dataValue2 = document.querySelector('#prenom').value
    const dataValue3 = document.querySelector('#email').value
    const dataValue4 = document.querySelector('#mdp').value
    const dataValue5 = document.querySelector('#tel').value
    const formData = new FormData()

    // On append à formData le contenu du formulaire
    formData.append('nom',dataValue)
    formData.append('prenom',dataValue2)
    formData.append('email',dataValue3)
    formData.append('mdp',dataValue4)
    formData.append('tel',dataValue5)
    
    if (navigator.onLine) {
        fetch('add-data-bdd.php', {
            method : 'POST',
            body: formData
        })
        
    }
})