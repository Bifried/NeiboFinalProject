const cacheName = 'cache-v1'; 
const filesToCache = [
    '/',
    '/main.js',
    '/main2.js',
    '../',
    'css/home.css',
    'css/styleConnexion.css',
    '../',
    'commerce.html',
    'home.html'
];


self.addEventListener('install', (event) => {
    console.log('Service Worker: Install', event);
    self.skipWaiting();
    event.waitUntil(
        caches.open(cacheName)
            .then(cache => cache.addAll(filesToCache))
    );
});

self.addEventListener('activate', (event) => {
    console.log('Service Worker: Activate', event);
    event.waitUntil(
        caches.keys()
            .then(cacheNames => 
                cacheNames
                    .filter(cache => cache !== cacheName)
                    .forEach(cache => {
                        console.log("Delete cache", cache);
                        caches.delete(cache);
                    })
            )
    );
});


self.addEventListener('fetch', (event) => {
   
    event.respondWith(
       
        caches.match(event.request).then((matchResponse) => {
            
            if(matchResponse !== undefined) return matchResponse;
            return fetch(event.request)
                .then(fetchResponse => fetchResponse)
                .catch(() => new Response(null, {
                    status: 501,
                    statusText: 'Service unavailable'
                }));
        })

    );
    console.log('Service Worker: Fetch', event);
});