document.addEventListener('submit',() => {

    if (navigator.onLine) {
        fetch('http://localhost:8888/neibo-project/login.php', {
        })
        
    }
})