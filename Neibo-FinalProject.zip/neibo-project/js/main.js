function initMap() {
  
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const  getAddress = async () =>{
          let lat = position.coords.latitude
          let long = position.coords.longitude
          let url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${long}&key=AIzaSyCn07pIPdU6DgccvDqdoju8wiYmihIQC1w`
          let response = await fetch(url)
          let address = await response.json()
          
          const location_text = document.querySelector('.location-text')
          location_text.textContent = address.results[0].formatted_address
          
        }
       getAddress()
        let myLatLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude )
        let mapOptions = {
          zoom: 12,
          center: myLatLng,
          disableDefaultUI: true,
          mapTypeControlOptions: {
            streetViewControl: false,
            mapTypeIds: google.maps.MapTypeId.ROADMAP
          }

        }
      
  
        let map;
        map = new google.maps.Map(document.getElementById("map"),mapOptions);
        let marker = new google.maps.Marker({
          position: myLatLng
        })
        marker.setMap(map)
    });
        } else {
          alert('Map is not available.');
        }
  }
 


initMap()



