<?php
// En cas de connexion
if(isset($_POST['submit']))  {

    $email = $_POST["email"];
    $mdp = $_POST["mdp"];

    $engine = "mysql";
    $host = "localhost";
    $port = 8889;  
    $dbname = "neibo";
    $username = "root";
    $password = "root"; 

    $pdo = new PDO("$engine:host=$host:$port;dbname=$dbname", $username, $password);

    $maRequete = $pdo->prepare("SELECT * from users WHERE email = :email");  
    $maRequete->execute([
        ":email" => $email
    ]); 

    if($maRequete->rowCount() > 0){
        $data = $maRequete->fetchAll();
        if(password_verify($mdp,$data[0]["password"])){   
            
            $_SESSION["connecte"] = true;
            http_response_code(302);
            header('Location: home.html');
            exit();
        }
        
    }
        
    }
?>
