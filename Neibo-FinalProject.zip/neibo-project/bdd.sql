CREATE DATABASE IF NOT EXISTS `neibo`  
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;  

use neibo;

CREATE TABLE `users` (   
    `id`  INT NOT NULL auto_increment,
    `nom` TEXT,   
    `prenom` TEXT, 
    `email` TEXT,
    `mdp` TEXT,
    `tel` INT,
    CONSTRAINT pk_users PRIMARY KEY (`id`)  
    ) ENGINE=InnoDB ;
